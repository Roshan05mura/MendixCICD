//>>built
define("dijit/hccss",["dojo/dom-class","dojo/hccss","dojo/domReady","dojo/_base/window"],function(_1,_2,_3,_4){
_3(function(){
if(_2("highcontrast")){
_1.add(_4.body(),"dijit_a11y");
}
});
return _2;
});
